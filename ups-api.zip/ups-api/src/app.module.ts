import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { APP_GUARD } from '@nestjs/core';
import { ThrottlerModule, ThrottlerGuard } from '@nestjs/throttler';
import { appConfig, AppConfig } from './config/app.config';
import { PrismaModule } from './database/prisma.module';
import { HealthModule } from './modules/health/health.module';
import { AuthModule } from './modules/auth/auth.module';
import { UsersModule } from './modules/users/users.module';
import { AuditLogsModule } from './modules/audit-logs/audit-logs.module';
import { RoutesModule } from './modules/routes/routes.module';
import { StopsModule } from './modules/stops/stops.module';
import { SchedulesModule } from './modules/schedules/schedules.module';
import { VehiclesModule } from './modules/vehicles/vehicles.module';
import { DriversModule } from './modules/drivers/drivers.module';
import { NoticesModule } from './modules/notices/notices.module';
import { MobileModule } from './modules/mobile/mobile.module';
import { TripFeedbackModule } from './modules/trip-feedback/trip-feedback.module';
import { JwtAuthGuard } from './common/guards/jwt-auth.guard';
import { RolesGuard } from './common/guards/roles.guard';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      load: [appConfig],
    }),
    ThrottlerModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (configService: ConfigService<AppConfig>) => {
        const config = configService.get('throttle', { infer: true });
        return [{
          ttl: config?.ttl ?? 60000,
          limit: config?.limit ?? 10,
        }];
      },
    }),
    PrismaModule,
    HealthModule,
    AuthModule,
    UsersModule,
    AuditLogsModule,
    RoutesModule,
    StopsModule,
    SchedulesModule,
    VehiclesModule,
    DriversModule,
    NoticesModule,
    MobileModule,
    TripFeedbackModule,
  ],
  providers: [
    {
      provide: APP_GUARD,
      useClass: JwtAuthGuard,
    },
    {
      provide: APP_GUARD,
      useClass: RolesGuard,
    },
    {
      provide: APP_GUARD,
      useClass: ThrottlerGuard,
    },
  ],
})
export class AppModule {}
